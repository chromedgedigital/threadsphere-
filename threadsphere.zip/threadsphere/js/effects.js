/* ═══════════════════════════════════════════
   js/effects.js
   Floating stickers, animated thread canvas,
   cursor sparkle trail.
   Edit THIS file to add/remove sticker types
   or change canvas thread behaviour.
═══════════════════════════════════════════ */

/* ── ANIMATED THREAD CANVAS ── */
(function () {
  const canvas = document.getElementById('threadCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, threads = [];

  function resize() { W = canvas.width = innerWidth; H = canvas.height = innerHeight; }
  resize();
  window.addEventListener('resize', resize);

  const colors = [
    'rgba(200,146,42,', 'rgba(192,87,42,',
    'rgba(122,158,126,', 'rgba(245,215,142,'
  ];

  function makeThread() {
    return {
      x: Math.random() * W, y: Math.random() * H,
      vx: (Math.random() - .5) * .4, vy: (Math.random() - .5) * .4,
      len: Math.random() * 80 + 40,
      angle: Math.random() * Math.PI * 2,
      angleV: (Math.random() - .5) * .015,
      color: colors[Math.floor(Math.random() * colors.length)],
      alpha: Math.random() * .4 + .15,
      w: Math.random() * 1.2 + .4,
      wave: Math.random() * Math.PI * 2,
      waveS: Math.random() * .02 + .005
    };
  }

  for (let i = 0; i < 28; i++) threads.push(makeThread());

  function draw() {
    ctx.clearRect(0, 0, W, H);
    threads.forEach(t => {
      t.x += t.vx; t.y += t.vy;
      t.angle += t.angleV; t.wave += t.waveS;
      if (t.x < -100 || t.x > W + 100) t.vx *= -1;
      if (t.y < -100 || t.y > H + 100) t.vy *= -1;
      ctx.beginPath();
      const pts = 12;
      for (let i = 0; i <= pts; i++) {
        const p = i / pts;
        const x = t.x + Math.cos(t.angle) * t.len * p + Math.sin(t.wave + p * 4) * 6;
        const y = t.y + Math.sin(t.angle) * t.len * p + Math.cos(t.wave + p * 4) * 4;
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.strokeStyle = t.color + t.alpha + ')';
      ctx.lineWidth = t.w;
      ctx.lineCap = 'round';
      ctx.stroke();
    });
    requestAnimationFrame(draw);
  }
  draw();
})();

/* ── FLOATING STICKERS ── */
(function () {
  const container = document.getElementById('stickers');
  if (!container) return;

  /* ── Define sticker types here — add more or remove any ── */
  const stickers = [
    // Thread spool
    () => { const d = document.createElement('div'); d.innerHTML = `<svg width="44" height="44" viewBox="0 0 44 44" xmlns="http://www.w3.org/2000/svg"><ellipse cx="22" cy="10" rx="14" ry="6" fill="#c8922a" opacity=".85"/><rect x="8" y="10" width="28" height="24" rx="2" fill="#e8b84b" opacity=".8"/><ellipse cx="22" cy="34" rx="14" ry="6" fill="#c8922a" opacity=".85"/><ellipse cx="22" cy="22" rx="8" ry="8" fill="none" stroke="#8b3318" stroke-width="2"/><path d="M8 14 Q22 18 36 14" stroke="#8b3318" stroke-width="1" fill="none"/><path d="M8 30 Q22 26 36 30" stroke="#8b3318" stroke-width="1" fill="none"/></svg>`; return d; },
    // Needle
    () => { const d = document.createElement('div'); d.innerHTML = `<svg width="12" height="60" viewBox="0 0 12 60" xmlns="http://www.w3.org/2000/svg"><path d="M6 0 L9 45 Q9 55 6 60 Q3 55 3 45 Z" fill="#b0b0b0" stroke="#888" stroke-width=".5"/><ellipse cx="6" cy="6" rx="3" ry="4" fill="#d0d0d0"/><ellipse cx="6" cy="5" rx="1.5" ry="2" fill="#555"/></svg>`; return d; },
    // Scissors
    () => { const d = document.createElement('div'); d.style.fontSize = '2rem'; d.textContent = '✂️'; return d; },
    // Gold sparkle
    () => { const d = document.createElement('div'); d.style.cssText = 'font-size:1.6rem;color:#c8922a'; d.textContent = '✦'; return d; },
    // Heart
    () => { const d = document.createElement('div'); d.style.fontSize = '1.5rem'; d.textContent = '🧡'; return d; },
    // Mini mandala
    () => { const d = document.createElement('div'); d.innerHTML = `<svg width="38" height="38" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg" fill="none"><circle cx="19" cy="19" r="17" stroke="#c8922a" stroke-width="1.2"/><circle cx="19" cy="19" r="12" stroke="#c0572a" stroke-width=".9"/><circle cx="19" cy="19" r="7" stroke="#c8922a" stroke-width=".8"/><circle cx="19" cy="19" r="3" fill="#e8b84b" opacity=".7"/><line x1="19" y1="2" x2="19" y2="36" stroke="#c8922a" stroke-width=".6"/><line x1="2" y1="19" x2="36" y2="19" stroke="#c8922a" stroke-width=".6"/><line x1="7" y1="7" x2="31" y2="31" stroke="#c0572a" stroke-width=".5"/><line x1="31" y1="7" x2="7" y2="31" stroke="#c0572a" stroke-width=".5"/></svg>`; return d; },
    // Flower
    () => { const d = document.createElement('div'); d.style.cssText = 'font-size:2rem;color:#e8b84b'; d.textContent = '❋'; return d; },
    // Leaf
    () => { const d = document.createElement('div'); d.innerHTML = `<svg width="30" height="40" viewBox="0 0 30 40" xmlns="http://www.w3.org/2000/svg"><path d="M15 38 Q2 28 2 18 Q2 4 15 2 Q28 4 28 18 Q28 28 15 38Z" fill="rgba(122,158,126,0.7)" stroke="#7a9e7e" stroke-width="1"/><line x1="15" y1="2" x2="15" y2="38" stroke="#5a7e5e" stroke-width=".8"/></svg>`; return d; },
    // Pin
    () => { const d = document.createElement('div'); d.style.fontSize = '1.8rem'; d.textContent = '📌'; return d; },
  ];

  function spawnSticker() {
    const fn = stickers[Math.floor(Math.random() * stickers.length)];
    const el = fn();
    const dur = Math.random() * 18 + 12;
    const size = Math.random() * 30 + 25;
    el.style.cssText += `;position:absolute;left:${Math.random() * 90 + 5}%;bottom:-80px;width:${size}px;height:auto;opacity:0;animation:stickerFloat ${dur}s ${Math.random() * 4}s linear forwards;transform:rotate(${(Math.random() - .5) * 60}deg);pointer-events:none;filter:drop-shadow(2px 4px 8px rgba(92,51,23,.25))`;
    container.appendChild(el);
    setTimeout(() => { if (el.parentNode) container.removeChild(el); }, (dur + 4) * 1000);
  }

  // Initial batch after loader hides
  for (let i = 0; i < 8; i++) setTimeout(() => spawnSticker(), i * 800 + 2500);

  // Continuous spawn
  setInterval(spawnSticker, 2200);
})();

/* ── CURSOR SPARKLE TRAIL ── */
(function () {
  // Inject sparkle keyframe dynamically
  const style = document.createElement('style');
  style.textContent = '@keyframes sparkFade{0%{opacity:1;transform:translate(-50%,-50%) scale(1)}100%{opacity:0;transform:translate(-50%,-80px) scale(0)}}';
  document.head.appendChild(style);

  document.addEventListener('mousemove', e => {
    if (Math.random() > .82) {
      const spark = document.createElement('div');
      spark.style.cssText = `position:fixed;left:${e.clientX}px;top:${e.clientY}px;width:6px;height:6px;border-radius:50%;background:${Math.random() > .5 ? '#c8922a' : '#e8b84b'};pointer-events:none;z-index:9997;transform:translate(-50%,-50%);animation:sparkFade .7s ease forwards`;
      document.body.appendChild(spark);
      setTimeout(() => spark.remove(), 700);
    }
  });
})();
