/* ═══════════════════════════════════════════
   js/animations.js
   Scroll reveal, section line reveal,
   counter animation, parallax effects.
   Edit THIS file to change scroll behaviour.
═══════════════════════════════════════════ */

/* ── SCROLL REVEAL (.rev elements) ── */
const revEls = document.querySelectorAll('.rev');
const revObs = new IntersectionObserver(entries =>
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('vis'); }),
  { threshold: .1 }
);
revEls.forEach(el => revObs.observe(el));

/* ── SECTION LINES ── */
const lineObs = new IntersectionObserver(entries =>
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('vis'); }),
  { threshold: .4 }
);
document.querySelectorAll('.sec-line').forEach(l => lineObs.observe(l));

/* ── GALLERY PAINT WIPE ── */
const gCards = document.querySelectorAll('.g-card');
const gObs = new IntersectionObserver(entries =>
  entries.forEach(e => { if (e.isIntersecting) setTimeout(() => e.target.classList.add('vis'), 100); }),
  { threshold: .12 }
);
gCards.forEach((c, i) => {
  c.style.transitionDelay = (i * .12) + 's';
  gObs.observe(c);
});

/* ── INSTAGRAM STAGGER ── */
const instaObs = new IntersectionObserver(entries =>
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('vis'); }),
  { threshold: .1 }
);
document.querySelectorAll('.insta-item').forEach(i => instaObs.observe(i));

/* ── PROCESS BOUNCE + DASHED LINE ── */
const procEl = document.getElementById('procSteps');
if (procEl) {
  const procObs = new IntersectionObserver(entries => entries.forEach(e => {
    if (e.isIntersecting) {
      procEl.classList.add('vis');
      document.querySelectorAll('.p-step').forEach(s => s.classList.add('vis'));
    }
  }), { threshold: .2 });
  procObs.observe(procEl);
}

/* ── PRICING LIST REVEAL ── */
const priceObs = new IntersectionObserver(entries =>
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('vis'); }),
  { threshold: .15 }
);
document.querySelectorAll('.price-card').forEach(c => priceObs.observe(c));

/* ── COUNTER ANIMATION ── */
function animCounter(el, target, duration = 1600) {
  let start = null;
  (function step(ts) {
    if (!start) start = ts;
    const progress = Math.min((ts - start) / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.floor(ease * target) + '+';
    if (progress < 1) requestAnimationFrame(step);
  })(performance.now());
}
const cntObs = new IntersectionObserver(entries => entries.forEach(e => {
  if (e.isIntersecting && e.target.dataset.target) {
    animCounter(e.target, +e.target.dataset.target);
    cntObs.unobserve(e.target);
  }
}), { threshold: .6 });
document.querySelectorAll('.stat-num[data-target]').forEach(el => cntObs.observe(el));

/* ── PARALLAX HERO BG on scroll ── */
window.addEventListener('scroll', () => {
  const bg = document.getElementById('heroBg');
  if (bg) bg.style.transform = `translateY(${scrollY * .22}px)`;
});

/* ── MOUSE PARALLAX (hero deco + blobs) ── */
document.addEventListener('mousemove', e => {
  const cx = innerWidth / 2, cy = innerHeight / 2;
  const dx = (e.clientX - cx) / cx;
  const dy = (e.clientY - cy) / cy;
  const deco = document.querySelector('.hero-deco');
  if (deco) deco.style.transform = `translateY(calc(-50% + ${dy * 18}px)) translateX(${dx * 18}px)`;
  const b1 = document.querySelector('.blob1');
  const b2 = document.querySelector('.blob2');
  if (b1) b1.style.transform = `translate(${dx * 12}px, ${dy * 12}px)`;
  if (b2) b2.style.transform = `translate(${-dx * 10}px, ${-dy * 10}px)`;
});

/* ── 3D TILT on pricing cards ── */
document.querySelectorAll('.price-card:not(.featured)').forEach(card => {
  card.addEventListener('mousemove', e => {
    const r = card.getBoundingClientRect();
    const dx = (e.clientX - r.left - r.width / 2) / (r.width / 2);
    const dy = (e.clientY - r.top - r.height / 2) / (r.height / 2);
    card.style.transform = `perspective(900px) rotateX(${-dy * 6}deg) rotateY(${dx * 6}deg) translateY(-12px)`;
  });
  card.addEventListener('mouseleave', () => card.style.transform = '');
});
