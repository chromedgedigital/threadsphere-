/* ═══════════════════════════════════════════
   js/interactions.js
   Loader, custom cursor, nav scroll behaviour,
   contact form submit, scroll-to-top button.
   Edit THIS file to change UI interactions.
═══════════════════════════════════════════ */

/* ── PAGE LOADER ── */
window.addEventListener('load', () => {
  setTimeout(() => {
    const loader = document.getElementById('loader');
    if (loader) loader.classList.add('hidden');
  }, 2000); // Change delay (ms) here
});

/* ── CUSTOM CURSOR ── */
const cur = document.getElementById('cur');
const ring = document.getElementById('cur-ring');
let mx = 0, my = 0, rx = 0, ry = 0;

document.addEventListener('mousemove', e => {
  mx = e.clientX; my = e.clientY;
  cur.style.left = mx + 'px';
  cur.style.top = my + 'px';
});

(function animRing() {
  rx += (mx - rx) * .1;
  ry += (my - ry) * .1;
  ring.style.left = rx + 'px';
  ring.style.top = ry + 'px';
  requestAnimationFrame(animRing);
})();

/* ── NAV SCROLL BEHAVIOUR ── */
const navEl = document.getElementById('nav');
const scrollTopBtn = document.getElementById('scrollTop');

window.addEventListener('scroll', () => {
  if (navEl) navEl.classList.toggle('scrolled', scrollY > 60);
  if (scrollTopBtn) scrollTopBtn.classList.toggle('show', scrollY > 400);
});

/* ── CONTACT FORM SUBMIT ── */
function handleSubmit(e) {
  e.preventDefault();
  const btn = e.target.querySelector('.form-submit');
  btn.textContent = '✅ Sent! We\'ll be in touch soon.';
  btn.style.background = 'linear-gradient(135deg, #7a9e7e, #5a7e5e)';
  btn.disabled = true;

  /* 
    TO CONNECT A REAL FORM SERVICE:
    Replace this block with your preferred service.
    Options: Formspree, EmailJS, Netlify Forms, etc.
    
    Example with Formspree:
    const data = new FormData(e.target);
    fetch('https://formspree.io/f/YOUR_ID', {
      method: 'POST', body: data,
      headers: { 'Accept': 'application/json' }
    });
  */
}

// Make handleSubmit globally accessible
window.handleSubmit = handleSubmit;
